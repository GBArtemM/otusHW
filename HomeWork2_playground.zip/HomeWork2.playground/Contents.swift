import UIKit

var numbers1 = [11, 22, 3, 4, 5, -22, 44, 54, 44]
let numbers2 = [11, 22, 33, 44, 55]
var resultArr: Set<Int> = []
var minValues = numbers1[0]
var maxValues = 0
var minPos = 0
var maxPos = 0
let users: [String: String] = ["Alexey": "q1w2e311111111111", "Daria": "w2e3r4", "Artem": "e3r4t5", "Anna": "1273ncjd93j9dj3ijbdy", "Ekaterina": "8cj8j80cundu", "Nikolay": "djd0c0"]
var passMore10: [String] = []
print("Исходный массив:", numbers1)

for i in 0..<numbers1.count {
    if numbers1[i] > maxValues {
        maxValues = numbers1[i]
        maxPos = i
    }
    if numbers1[i] < minValues {
        minValues = numbers1[i]
        minPos = i
    }
}
numbers1.swapAt(minPos, maxPos)
print("1. Массив после замены минимального и максимального числа:", numbers1)

numbers1.forEach { num1 in
    numbers2.forEach{ num2 in
        if num1 == num2{
            resultArr.insert(num1)
        }
    }
}
print("2. Множество из символом, которые повторяются в двух массивах:" , resultArr)

for (name, pass) in users {
    if pass.count > 10 {
        passMore10.append(name)
    }
}
print("3. Имена, пароли которых длиннее 10 символов:", passMore10)
